1307scout brand kit
===================

Free scouting for every FRC team: https://scout.robosaints1307.com
The full guide, with previews, is on the site at /brand.html.

FOLDERS
  svg/  Vector files. Use these for printing (stickers, shirts, banners): they scale to any size.
        All lettering is already converted to outlines, so no fonts are needed.
  png/  Large transparent PNGs (2048 px on the long side; the badge, tee and poster at print size)
        for slides, documents and social posts.

LOGOS
  1307scout-lockup        Main logo: the mark beside the wordmark. Use it first.
  1307scout-stacked       Mark above the wordmark, for square or tall spaces.
  1307scout-mark          The app icon tile. Use where the name already appears nearby.
  1307scout-symbol        The gear-and-reticle symbol alone, no tile.
  1307scout-wordmark      The name alone.
  ...-white               For navy, black or photo backgrounds.
  ...-black               One color, for vinyl cutting, laser engraving, embroidery and fax-grade printing.

STICKERS AND MERCH
  sticker-round           3 in circle            sticker-hex         2 in hexagon (pointy top)
  sticker-diecut          Logo plate, cut on the outline
  sticker-trust-the-data  sticker-scouted        sticker-no-wifi
  badge-scout             3 x 4 in lanyard badge for scouts (write name, team and circle the seat)
  tee-back                Back print for a navy or black shirt (white, ice and signal inks)
  poster-pit              8.5 x 11 in poster for the pit table, with a QR code to the site
  qr-scout                QR code to scout.robosaints1307.com

COLORS
  Navy    #0A2352  RGB 10 35 82     Plates, backgrounds, the wordmark's "scout"
  Blue    #1B4DB1  RGB 27 77 177    The wordmark's "1307" on light backgrounds, buttons
  Signal  #4479E3  RGB 68 121 227   The radar sweep, accents on navy
  Ice     #7FA6F7  RGB 127 166 247  "1307" and accents on navy
  Paper   #F4F7FC  RGB 244 247 252  Light backgrounds
  Alliance red #C0392B and blue #1B4DB1 are for red/blue alliance information only.

TYPE
  Chakra Petch (display: the wordmark, headings) and IBM Plex Sans (body text). Both are free
  from Google Fonts under the SIL Open Font License.

USING THE LOGO
  - Leave clear space around it at least as big as the tile's cut corner.
  - Smallest sizes: the mark 16 px (screen) or 0.25 in (print); the lockup 120 px or 1 in wide.
  - Don't stretch, rotate, recolor, outline, add shadows to, or rearrange the pieces.
  - Keep "1307" and "scout" together as one word, lowercase "scout".
  - On busy photos, put the logo on a navy or white plate.
